package com.bloodline.mobdrops;

import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.UseCooldownComponent;
import net.minecraft.entity.EntityType;
import net.minecraft.item.Items;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.function.SetComponentsLootFunction;
import net.minecraft.loot.function.SetCountLootFunction;
import net.minecraft.loot.provider.number.UniformLootNumberProvider;
import net.minecraft.util.Identifier;


public class MobLootTables {
    public static void register() {
        LootTableEvents.MODIFY.register((key, tableBuilder, source, registries) -> {
            if (key.getValue().equals(Identifier.of("minecraft", "gameplay/piglin_bartering"))) {
                tableBuilder.pool(
                        LootPool.builder()
                                .rolls(UniformLootNumberProvider.create(1.0f, 2.0f))
                                .with(
                                        ItemEntry.builder(Items.ENDER_PEARL)
                                                .apply(SetCountLootFunction.builder(
                                                        UniformLootNumberProvider.create(2.0f, 5.0f)
                                                ))
                                                .apply(SetComponentsLootFunction.builder(
                                                        DataComponentTypes.USE_COOLDOWN,
                                                        new UseCooldownComponent(120)
                                                ))
                               )
                );
            }

            if (key.equals(EntityType.SLIME.getLootTableKey().orElseThrow())) {
                tableBuilder.pool(
                        LootPool.builder()
                                .rolls(UniformLootNumberProvider.create(0.0f, 10.0f))
                                .with(ItemEntry.builder(Items.SLIME_BALL))
                );
            }

            if (key.equals(EntityType.BREEZE.getLootTableKey().orElseThrow())) {
                tableBuilder.pool(
                        LootPool.builder()
                                .rolls(UniformLootNumberProvider.create(0.0f, 32.0f))
                                .with(ItemEntry.builder(Items.BREEZE_ROD))
                );
            }

            if (key.equals(EntityType.CREEPER.getLootTableKey().orElseThrow())) {
                tableBuilder.pool(
                        LootPool.builder()
                                .rolls(UniformLootNumberProvider.create(0.0f, 10.0f))
                                .with(ItemEntry.builder(Items.GUNPOWDER))
                );
            }

            if (key.equals(EntityType.SHULKER.getLootTableKey().orElseThrow())) {
                tableBuilder.pool(
                        LootPool.builder()
                                .rolls(UniformLootNumberProvider.create(0.0f, 10.0f))
                                .with(ItemEntry.builder(Items.SHULKER_SHELL))
                );
            }

            if (key.equals(EntityType.BEE.getLootTableKey().orElseThrow())) {
                tableBuilder.pool(
                        LootPool.builder()
                                .rolls(UniformLootNumberProvider.create(0.0f, 10.0f))
                                .with(ItemEntry.builder(Items.HONEY_BLOCK))
                );
            }
        });

        LootTableEvents.REPLACE.register((key, tableBuilder, source, registries) -> {
            if (key.equals(EntityType.ENDERMAN.getLootTableKey().orElseThrow())) {
                LootTable.Builder builder = LootTable.builder();
                LootPool.Builder pool = LootPool.builder()
                        .rolls(UniformLootNumberProvider.create(0.0f,5.0f))
                        .with(
                                ItemEntry.builder(Items.ENDER_PEARL)
                                .apply(SetComponentsLootFunction.builder(
                                        DataComponentTypes.USE_COOLDOWN,
                                        new UseCooldownComponent(120)
                                ))
                        );
                builder.pool(pool);

                return builder.build();
            }
            return null;
        });
    }
}
