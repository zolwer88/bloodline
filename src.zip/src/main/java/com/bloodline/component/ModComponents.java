package com.bloodline.component;

import com.mojang.serialization.Codec;
import net.minecraft.component.ComponentType;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;


public class ModComponents {

    public static final ComponentType<Boolean> IS_HEART = Registry.register(
            Registries.DATA_COMPONENT_TYPE,
            Identifier.of("bloodline", "is_heart"),
            ComponentType.<Boolean>builder()
                    .codec(Codec.BOOL)
                    .packetCodec(PacketCodecs.BOOLEAN)
                    .build()
    );

    public static final ComponentType<Boolean> IS_LEGAL_NETHERITE = Registry.register(
            Registries.DATA_COMPONENT_TYPE,
            Identifier.of("bloodline", "is_legal_netherite"),
            ComponentType.<Boolean>builder()
                    .codec(Codec.BOOL)
                    .packetCodec(PacketCodecs.BOOLEAN)
                    .build()
    );

    public static final ComponentType<Boolean> IS_LEGAL_CART = Registry.register(
            Registries.DATA_COMPONENT_TYPE,
            Identifier.of("bloodline", "is_legal_cart"),
            ComponentType.<Boolean>builder()
                    .codec(Codec.BOOL)
                    .packetCodec(PacketCodecs.BOOLEAN)
                    .build()
    );

    public static final ComponentType<Boolean> IS_SKULL_LAUNCHER = Registry.register(
            Registries.DATA_COMPONENT_TYPE,
            Identifier.of("bloodline", "is_skull_launcher"),
            ComponentType.<Boolean>builder()
                    .codec(Codec.BOOL)
                    .packetCodec(PacketCodecs.BOOLEAN)
                    .build()
    );

    public static final ComponentType<Boolean> IS_STORM_BREAKER = Registry.register(
            Registries.DATA_COMPONENT_TYPE,
            Identifier.of("bloodline", "is_storm_breaker"),
            ComponentType.<Boolean>builder()
                    .codec(Codec.BOOL)
                    .packetCodec(PacketCodecs.BOOLEAN)
                    .build()
    );

    public static final ComponentType<Integer> STORM_BREAKER_HITS = Registry.register(
            Registries.DATA_COMPONENT_TYPE,
            Identifier.of("bloodline", "storm_breaker_hits"),
            ComponentType.<Integer>builder()
                    .codec(Codec.INT)
                    .packetCodec(PacketCodecs.INTEGER)
                    .build()
    );

    public static final ComponentType<Boolean> DONT_DISABLE_HIT_ON_COOLDOWN = Registry.register(
            Registries.DATA_COMPONENT_TYPE,
            Identifier.of("bloodline", "dont_dissable_hit_on_cooldown"),
            ComponentType.<Boolean>builder()
                    .codec(Codec.BOOL)
                    .packetCodec(PacketCodecs.BOOLEAN)
                    .build()
    );

    public static final ComponentType<Boolean> IS_SONIC_AURA = Registry.register(
            Registries.DATA_COMPONENT_TYPE,
            Identifier.of("bloodline", "is_sonic_aura"),
            ComponentType.<Boolean>builder()
                    .codec(Codec.BOOL)
                    .packetCodec(PacketCodecs.BOOLEAN)
                    .build()
    );

    public static final ComponentType<Boolean> IS_BIG_AXE = Registry.register(
            Registries.DATA_COMPONENT_TYPE,
            Identifier.of("bloodline", "is_big_axe"),
            ComponentType.<Boolean>builder()
                    .codec(Codec.BOOL)
                    .packetCodec(PacketCodecs.BOOLEAN)
                    .build()
    );

    public static final ComponentType<Integer> BIG_AXE_COOLDOWN = Registry.register(
            Registries.DATA_COMPONENT_TYPE,
            Identifier.of("bloodline", "big_axe_cooldown"),
            ComponentType.<Integer>builder()
                    .codec(Codec.INT)
                    .packetCodec(PacketCodecs.INTEGER)
                    .build()
    );

    public static final ComponentType<Boolean> IS_WEB_BALL_LAUNCHER = Registry.register(
            Registries.DATA_COMPONENT_TYPE,
            Identifier.of("bloodline", "is_web_ball_launcher"),
            ComponentType.<Boolean>builder()
                    .codec(Codec.BOOL)
                    .packetCodec(PacketCodecs.BOOLEAN)
                    .build()
    );

    public static final ComponentType<Boolean> IS_WEB_BALL = Registry.register(
            Registries.DATA_COMPONENT_TYPE,
            Identifier.of("bloodline", "is_web_ball"),
            ComponentType.<Boolean>builder()
                    .codec(Codec.BOOL)
                    .packetCodec(PacketCodecs.BOOLEAN)
                    .build()
    );



    public static void register() {};
}
