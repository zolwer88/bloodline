package com.bloodline.events;

import com.bloodline.component.ModComponents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;

public class StormBreakerHit {
    public static void register() {
        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamageTaken, damageTaken, blocked) -> {
            Entity attacker = source.getAttacker();
            if (!(attacker instanceof PlayerEntity player)) {return;}

            ItemStack weapon = player.getMainHandStack();

            if (!weapon.isOf(Items.IRON_SWORD)) {return;}

            if (Boolean.FALSE.equals(weapon.get(ModComponents.IS_STORM_BREAKER))) {return;}

            if (blocked) {return;}

            Integer hits = weapon.get(ModComponents.STORM_BREAKER_HITS);

            if (hits == null) {weapon.set(ModComponents.STORM_BREAKER_HITS, 2); return;}

            if (hits < 5) {
                weapon.set(ModComponents.STORM_BREAKER_HITS, (hits + 1));
            }
            else {
                ServerWorld world = (ServerWorld) entity.getEntityWorld();

                LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(world, SpawnReason.TRIGGERED);

                if (bolt == null) {return;}

                bolt.refreshPositionAfterTeleport(entity.getEntityPos());

                world.spawnEntity(bolt);

                weapon.set(ModComponents.STORM_BREAKER_HITS, 0);

                entity.damage(world, source, 20.0F);
            }
        });
    }
}