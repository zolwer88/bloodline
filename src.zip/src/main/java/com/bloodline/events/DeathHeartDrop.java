package com.bloodline.events;

import com.bloodline.helpers.HeartHelper;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;

public class DeathHeartDrop {
    public static void register() {
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (entity instanceof ServerPlayerEntity player) {
                var attribute = player.getAttributeInstance(EntityAttributes.MAX_HEALTH);

                if (attribute.getBaseValue() > 6.0f) {
                    ItemStack heart = HeartHelper.makeHeart();

                    player.dropItem(heart, true);
                    attribute.setBaseValue(attribute.getBaseValue() - 2.0);
                }
            }
        });
    }
}