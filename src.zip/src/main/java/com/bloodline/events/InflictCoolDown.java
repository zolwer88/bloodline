package com.bloodline.events;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;

public class InflictCoolDown {
    public static void register() {
        ServerLivingEntityEvents.AFTER_DAMAGE.register(((entity, source, baseDamageTaken, damageTaken, blocked) -> {
            var attacker = source.getAttacker();
            if (!(attacker instanceof ServerPlayerEntity player)) {
                return;
            }

            if (blocked) {return;}

            ItemStack mainHand = player.getMainHandStack();

            if (mainHand.isOf(Items.MACE)) {
                player.getItemCooldownManager().set(mainHand, 3600);
            }
        }));
    }
}
