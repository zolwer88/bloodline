package com.bloodline.events;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.projectile.WitherSkullEntity;
import net.minecraft.server.world.ServerWorld;

public class SkullDamageBuff {
    public static void register() {
        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamageTaken, damageTaken, blocked) -> {

            if (source.getSource() instanceof WitherSkullEntity) {

                ServerWorld world = (ServerWorld) entity.getEntityWorld();

                DamageSource extraDamage = world.getDamageSources().wither();

                entity.damage(world, extraDamage, 32.0F);
            }
        });
    }
}