package com.bloodline.events;


import com.bloodline.component.ModComponents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;

public class InforceCoolDown {
    public static void register() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            ItemStack weapon = player.getStackInHand(hand);

            var dont_disable = weapon.get(ModComponents.DONT_DISABLE_HIT_ON_COOLDOWN);

            if (dont_disable != null && dont_disable) {
                return ActionResult.PASS;
            }

            if (player.getItemCooldownManager().isCoolingDown(weapon)) {
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });
    }
}
