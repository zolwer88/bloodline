package com.bloodline;

import com.bloodline.commands.*;
import com.bloodline.items.*;
import net.fabricmc.api.ModInitializer;

import com.bloodline.component.ModComponents;
import com.bloodline.events.*;
import com.bloodline.mobdrops.MobLootTables;

public class BloodlineServerMod implements ModInitializer {
	public static final String MOD_ID = "bloodline-server-mod";

	@Override
	public void onInitialize() {
		ModComponents.register();
		UseHeart.register();
		UseEgg.register();
		UseSkullLauncher.register();
		UseSonicAura.register();
		UseWebBallLauncher.register();
		DeathHeartDrop.register();
		InflictCoolDown.register();
		InforceCoolDown.register();
		SkullDamageBuff.register();
		StormBreakerHit.register();
		WithdrawCMD.register();
		CraftHeartCMD.register();
		CraftVillagerCMD.register();
		CraftHayCMD.register();
		CraftGapCMD.register();
		CraftCartCMD.register();
		CraftGoldCMD.register();
		EasyTradeCMD.register();
		MobLootTables.register();
	}
}