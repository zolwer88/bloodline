package com.bloodline.mixin;

import com.bloodline.component.ModComponents;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SnowballEntity.class)
public class SnowBallEntityMixin {
    @Inject(
            method = "onCollision",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/projectile/thrown/SnowballEntity;discard()V",
                    shift = At.Shift.BEFORE
            )
    )
    private void beforeDiscard(CallbackInfo ci) {
        ProjectileEntity ball = ((ProjectileEntity)(Object)this);

        var is_web_ball = ball.get(ModComponents.IS_WEB_BALL);
        if (is_web_ball == null || !is_web_ball) {return;}

        Vec3d pos = ball.getEntityPos().add(new Vec3d(0.0, 0.5, 0.0));

        ServerWorld world = (ServerWorld)ball.getEntityWorld();
        for (int x = -1; x < 2; x++) {
            for (int y = -1; y < 2; y++) {
                for (int z = -1; z < 2; z++) {
                    BlockPos blockPos = new BlockPos(
                            (int)pos.x + x,
                            (int)pos.y + y,
                            (int)pos.z + z
                    );

                    BlockState block = world.getBlockState(blockPos);

                    if (block.isOf(Blocks.AIR)) {
                        world.setBlockState(blockPos, Blocks.COBWEB.getDefaultState());
                    }

                }
            }
        }
    }
}
