package com.bloodline.mixin;

import net.minecraft.block.BlockState;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.fluid.FluidState;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.explosion.Explosion;
import net.minecraft.world.explosion.ExplosionBehavior;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

import java.util.Optional;

@Mixin(RespawnAnchorBlock.class)
public class RespawnAnchorBlockMixin {
    @Overwrite
    private void explode(final BlockState state, final ServerWorld world, final BlockPos pos) {
        world.removeBlock(pos, false);
        boolean anyWaterNeighbors = Direction.Type.HORIZONTAL.stream().map(pos::offset).anyMatch(neighborPos -> world.getFluidState(neighborPos).isIn(FluidTags.WATER));
        final boolean inWater = anyWaterNeighbors || world.getFluidState(pos.up()).isIn(FluidTags.WATER);
        ExplosionBehavior damageCalculator = new ExplosionBehavior() {
            @Override
            public Optional<Float> getBlastResistance(
                    Explosion explosion,
                    BlockView worldView,
                    BlockPos testPos,
                    BlockState block,
                    FluidState fluid)
            {
                return super.getBlastResistance(explosion, worldView, testPos, block, fluid);
            }
        };
        Vec3d boomPos = new Vec3d(
                pos.getX(),
                pos.getY(),
                pos.getZ()
        );

        world.createExplosion(
                null,
                world.getDamageSources().badRespawnPoint(boomPos),
                damageCalculator,
                boomPos,
                1F,
                true,
                World.ExplosionSourceType.BLOCK);
    }
}