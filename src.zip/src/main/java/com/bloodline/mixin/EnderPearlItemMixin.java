package com.bloodline.mixin;

import com.bloodline.interfaces.LivingEntityAccess;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.EnderPearlItem;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EnderPearlItem.class)
public class EnderPearlItemMixin {

    @Inject(method = "use", at = @At("RETURN"))
    private void pearlCooldown(
            World world,
            PlayerEntity player,
            Hand hand,
            CallbackInfoReturnable<ActionResult> cir
    ) {
        if (!world.isClient() && cir.getReturnValue() == ActionResult.SUCCESS) {
            ((LivingEntityAccess) player).bloodline$setPearlCooldownDelay(5);
        }
    }
}