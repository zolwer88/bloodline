package com.bloodline.mixin;

import com.bloodline.component.ModComponents;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(TntMinecartEntity.class)
public class TntMinecartEntityMixin {
    @Inject(
            method = "getPickBlockStack",
            at = @At("RETURN"),
            cancellable = true
    )
    private void copyCartComponentToItem(CallbackInfoReturnable<ItemStack> cir) {
        ItemStack stack = cir.getReturnValue();

        if (stack == null) return;

        AbstractMinecartEntity cart = (AbstractMinecartEntity)(Object)this;

        if (cart.get(ModComponents.IS_LEGAL_CART) != null) {
            stack.set(
                    ModComponents.IS_LEGAL_CART,
                    cart.get(ModComponents.IS_LEGAL_CART)
            );
        }

        cir.setReturnValue(stack);
    }
}
