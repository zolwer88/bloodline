package com.bloodline.mixin;

import com.bloodline.component.ModComponents;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractMinecartEntity.class)
public abstract class AbstractMinecartEntityMixin {

    // Item -> Entity
    @Inject(
            method = "create",
            at = @At("RETURN")
    )
    private static void copyItemComponentToCart(
            World world,
            double x,
            double y,
            double z,
            EntityType<?> type,
            SpawnReason reason,
            ItemStack stack,
            PlayerEntity player,
            CallbackInfoReturnable<AbstractMinecartEntity> cir
    ) {
        AbstractMinecartEntity cart = cir.getReturnValue();

        if (cart == null) return;

        if (stack.contains(ModComponents.IS_LEGAL_CART)) {
            cart.setComponent(
                    ModComponents.IS_LEGAL_CART,
                    stack.get(ModComponents.IS_LEGAL_CART)
            );
        }
    }
}