package com.bloodline.mixin;

import com.bloodline.component.ModComponents;
import com.bloodline.interfaces.LivingEntityAccess;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.slot.Slot;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin implements LivingEntityAccess {

    @Shadow
    public abstract float getMaxHealth();

    @Shadow
    public abstract void setHealth(float health);

    @Shadow
    public abstract float getHealth();

    @Shadow
    public abstract ItemStack getMainHandStack();

    @Shadow
    public abstract ItemStack getOffHandStack();

    @Inject(method = "tick", at = @At("TAIL"))
    private void checkItems(CallbackInfo ci) {
        LivingEntity entity = (LivingEntity)(Object)this;

        for (EquipmentSlot slot : EquipmentSlot.values()) {

            ItemStack stack = entity.getEquippedStack(slot);

            if (stack.isOf(Items.NETHERITE_HELMET) ||
                    stack.isOf(Items.NETHERITE_CHESTPLATE) ||
                    stack.isOf(Items.NETHERITE_LEGGINGS) ||
                    stack.isOf(Items.NETHERITE_BOOTS)) {
                    Boolean allowed = stack.get(ModComponents.IS_LEGAL_NETHERITE);

                    if (!Boolean.TRUE.equals(allowed)) {
                            stack = new ItemStack(Items.ROTTEN_FLESH);
                            entity.equipStack(slot, stack);
                    }
            }
        }

        if (entity instanceof PlayerEntity player) {
            PlayerInventory inv = player.getInventory();

            // Hotbar (slots 0-8)
            for (int i = 0; i < 9; i++) {
                ItemStack stack = inv.getStack(i);

                if (stack.isOf(Items.TNT_MINECART)) {
                    Boolean allowed = stack.get(ModComponents.IS_LEGAL_CART);

                    if (!Boolean.TRUE.equals(allowed)) {
                        inv.setStack(i, new ItemStack(Items.ROTTEN_FLESH));
                    }
                }
            }

            // Offhand
            ItemStack offhand = player.getOffHandStack();

            if (offhand.isOf(Items.TNT_MINECART)) {
                Boolean allowed = offhand.get(ModComponents.IS_LEGAL_CART);

                if (!Boolean.TRUE.equals(allowed)) {
                    player.setStackInHand(Hand.OFF_HAND, new ItemStack(Items.ROTTEN_FLESH));
                }
            }
        }
    }
    @Inject(method = "tick", at = @At("TAIL"))
    private void eggEffect(CallbackInfo ci) {
        if ((Object)this instanceof PlayerEntity player) {
            PlayerInventory inv = player.getInventory();
            for (int i = 0; i < 36; i++) {
                ItemStack stack = inv.getStack(i);

                if (stack.isOf(Items.DRAGON_EGG)) {
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 2, 0));
                }
            }
        }
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void tickPearlCooldownDelay(CallbackInfo ci) {
        if (this.bloodline$pearlCooldownDelay == 1) {
            if ((LivingEntity)(Object)this instanceof PlayerEntity player) {
                player.getItemCooldownManager().set(new ItemStack(Items.ENDER_PEARL), 1200);
            }
        }
        if (this.bloodline$pearlCooldownDelay > 0) {this.bloodline$pearlCooldownDelay--;}
    }


    @Unique
    private int bloodline$pearlCooldownDelay = 0;

    @Unique
    public void bloodline$setPearlCooldownDelay(int delay) {
        this.bloodline$pearlCooldownDelay = delay;
    }

}