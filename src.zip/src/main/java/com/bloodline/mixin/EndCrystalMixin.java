package com.bloodline.mixin;

import net.minecraft.entity.decoration.EndCrystalEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(EndCrystalEntity.class)
public abstract class EndCrystalMixin {
    @ModifyConstant(
            method = "damage",
            constant = @Constant(floatValue = 6.0F)
    )
    private float changeExplosionPower(float original) {
        return 1F;
    }
}