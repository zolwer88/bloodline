package com.bloodline.mixin;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentEffectContext;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.effect.EnchantmentEntityEffect;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.server.world.ServerWorld;
import org.apache.commons.lang3.mutable.MutableFloat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(EnchantmentHelper.class)
public class EnchantmentHelperMixin {

    @Overwrite
    public static float getProtectionAmount(ServerWorld world,
                                            LivingEntity user,
                                            DamageSource source) {

        MutableFloat result = new MutableFloat(0.0F);

        EnchantmentHelper.forEachEnchantment(
                user,
                (RegistryEntry<Enchantment> enchantment, int level, EnchantmentEffectContext context) -> {
                    enchantment.value().modifyDamageProtection(
                            world,
                            Math.min(level, 3),
                            context.stack(),
                            user,
                            source,
                            result
                    );
                }
        );

        return result.floatValue();
    }

    @Overwrite
    public static float modifyKnockback(
            final ServerWorld serverWorld,
            final ItemStack itemStack,
            final Entity victim,
            final DamageSource damageSource,
            final float knockback
    ) {
        MutableFloat result = new MutableFloat(knockback);
        int doKb;
        if (itemStack.isOf(Items.WOODEN_SWORD) || itemStack.isIn(ItemTags.SPEARS)) {
            doKb = 1;
        }
        else {
            doKb = 0;
        }
        EnchantmentHelper.forEachEnchantment(itemStack, (enchantment, level) -> enchantment.value()
                .modifyKnockback(serverWorld,
                        level * doKb,
                        itemStack,
                        victim,
                        damageSource,
                        result));
        return result.floatValue();
    }

    @Overwrite
    public static float getArmorEffectiveness(
            ServerWorld serverWorld,
            ItemStack itemStack,
            Entity entity,
            DamageSource damageSource,
            float armorFraction
    ) {
        MutableFloat result = new MutableFloat(armorFraction);

        EnchantmentHelper.forEachEnchantment(
                itemStack,
                (enchantment, level) ->
                        enchantment.value().modifyArmorEffectiveness(
                                serverWorld,
                                Math.min(1, level),
                                itemStack,
                                entity,
                                damageSource,
                                result
                        )
        );

        return result.floatValue();
    }

    @Overwrite
    public static float getSmashDamagePerFallenBlock(
            final ServerWorld serverWorld,
            final ItemStack itemStack,
            final Entity victim,
            final DamageSource damageSource,
            final float damage
    ) {
        MutableFloat result = new MutableFloat(damage);
        EnchantmentHelper.forEachEnchantment(
                itemStack, (enchantment, level) -> enchantment.value().modifySmashDamagePerFallenBlock(
                        serverWorld,
                        Math.min(1, level),
                        itemStack,
                        victim,
                        damageSource,
                        result)
        );
        return result.floatValue();
    }
}