package com.bloodline.items;

import com.bloodline.helpers.HeartHelper;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.util.ActionResult;

public class UseHeart {
    public static void register() {
        UseItemCallback.EVENT.register((player, world, hand) -> {
            var stack = player.getStackInHand(hand);

            if (!HeartHelper.isHeart(stack)) {
                return ActionResult.PASS;
            }

            if (player.getMaxHealth() > 38) {
                return ActionResult.PASS;
            }

            if (!world.isClient()) {
                var attribute = player.getAttributeInstance(EntityAttributes.MAX_HEALTH);

                if (attribute != null) {
                    attribute.setBaseValue(attribute.getBaseValue() + 2);
                }

                stack.decrement(1);
            }

            return ActionResult.SUCCESS;
        });
    }
}
