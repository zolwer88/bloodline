package com.bloodline.items;

import com.bloodline.component.ModComponents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.entity.projectile.WitherSkullEntity;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Vec3d;

public class UseSkullLauncher {
    public static void register() {
        UseItemCallback.EVENT.register((player, world, hand) -> {
            var stack = player.getStackInHand(hand);

            if (!stack.isOf(Items.NETHER_STAR)) {
                return ActionResult.PASS;
            }

            if (!stack.get(ModComponents.IS_SKULL_LAUNCHER)) {
                return ActionResult.PASS;
            }

            if (!world.isClient()) {
                if (player.getItemCooldownManager().isCoolingDown(stack)) {
                    return ActionResult.PASS;
                }
                var look = player.getRotationVec(1.0F);
                WitherSkullEntity skull = new WitherSkullEntity(world,
                        player,
                        new Vec3d(look.x, look.y, look.z)
                        );

                skull.setPos(
                        player.getX() + look.x,
                        player.getEyeY() - 0.1,
                        player.getZ() + look.z
                );

                world.spawnEntity(skull);

                player.getItemCooldownManager().set(stack, 1800);
            }

            return ActionResult.SUCCESS;
        });
    }
}
