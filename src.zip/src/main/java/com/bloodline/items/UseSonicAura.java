package com.bloodline.items;

import com.bloodline.component.ModComponents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.entity.Entity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Box;
import java.util.List;


public class UseSonicAura {
    public static void register() {
        UseItemCallback.EVENT.register((player, world, hand) -> {
            var stack = player.getStackInHand(hand);

            if (!stack.isOf(Items.MUSIC_DISC_5)) {
                return ActionResult.PASS;
            }

            var isSonicAura = stack.get(ModComponents.IS_SONIC_AURA);

            if (isSonicAura == null || !isSonicAura) {
                return ActionResult.PASS;
            }

            if (!world.isClient()) {
                if (player.getItemCooldownManager().isCoolingDown(stack)) {
                    return ActionResult.PASS;
                }

                Box box = new Box(
                        player.getX() - 5, player.getY() - 5, player.getZ() - 5,
                        player.getX() + 5, player.getY() + 5, player.getZ() + 5
                );

                List<Entity> entities = world.getOtherEntities(
                        player,
                        box
                );

                for (Entity entity : entities) {
                    DamageSource extraDamage = world.getDamageSources().sonicBoom(player);

                    entity.damage((ServerWorld) world, extraDamage, 14.0F);

                    for (double i = 0; i < 5; i += 1) {
                        ((ServerWorld) world).spawnParticles(
                                ParticleTypes.SONIC_BOOM,
                                entity.getX(),
                                entity.getY() + i,
                                entity.getZ(),
                                0,
                                0.0,
                                0.0,
                                0.0,
                                0.0
                        );
                    }
                    world.playSound(
                            entity,
                            entity.getX(),
                            entity.getY(),
                            entity.getZ(),
                            SoundEvents.ENTITY_WARDEN_SONIC_BOOM,
                            SoundCategory.NEUTRAL
                    );
                }

                player.getItemCooldownManager().set(stack, 1800);
            }

            return ActionResult.SUCCESS;
        });
    }
}
