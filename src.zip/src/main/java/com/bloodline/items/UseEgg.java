package com.bloodline.items;

import com.bloodline.helpers.HeartHelper;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;

public class UseEgg {
    public static void register() {
        UseItemCallback.EVENT.register((player, world, hand) -> {
            var stack = player.getStackInHand(hand);

            if (!stack.isOf(Items.DRAGON_EGG)) {
                return ActionResult.PASS;
            }

            if (!world.isClient()) {
                if (player.getItemCooldownManager().isCoolingDown(stack)) {
                    return ActionResult.PASS;
                }
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 1200, 1));
                player.getItemCooldownManager().set(stack, 1800);
            }

            return ActionResult.SUCCESS;
        });
    }
}
