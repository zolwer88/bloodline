package com.bloodline.items;

import com.bloodline.component.ModComponents;
import com.bloodline.helpers.HeartHelper;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;

public class UseWebBallLauncher {
    public static void register() {
        UseItemCallback.EVENT.register((player, world, hand) -> {
            var stack = player.getStackInHand(hand);

            if (!stack.isOf(Items.SUGAR)) {
                return ActionResult.PASS;
            }

            var isSnowBallLauncher = stack.get(ModComponents.IS_WEB_BALL_LAUNCHER);

            if (isSnowBallLauncher == null || !isSnowBallLauncher) {
                return ActionResult.PASS;
            }

            if (!world.isClient()) {
                if (player.getItemCooldownManager().isCoolingDown(stack)) {
                    return ActionResult.PASS;
                }
                SnowballEntity webBall = new SnowballEntity(
                        world,
                        player,
                        stack

                );

                webBall.setPosition(player.getEntityPos().add(player.getRotationVec(1.0F)));
                webBall.setVelocity(player.getRotationVec(1.0F).multiply(1.5));
                webBall.setComponent(ModComponents.IS_WEB_BALL, true);

                world.spawnEntity(webBall);

                player.getItemCooldownManager().set(stack, 1200);
            }

            return ActionResult.SUCCESS;
        });
    }
}
