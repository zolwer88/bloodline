package com.bloodline.interfaces;

public interface LivingEntityAccess {
    void bloodline$setPearlCooldownDelay(int delay);
}
