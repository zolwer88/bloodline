package com.bloodline.helpers;

import com.bloodline.component.ModComponents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class HeartHelper {
    public static Boolean isHeart(ItemStack item) {
        if (!item.isOf(Items.RED_DYE)) {return false;}

        Boolean isAHeart = item.get(ModComponents.IS_HEART);
        if (isAHeart == null || !isAHeart) {return false;}

        return true;
    }

    public static ItemStack makeHeart() {
        ItemStack heart = new ItemStack(Items.RED_DYE);

        heart.set(ModComponents.IS_HEART, true);
        heart.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        heart.set(DataComponentTypes.CUSTOM_NAME,
                Text.literal("Heart").formatted(Formatting.DARK_RED));

        return heart;
    }
}
