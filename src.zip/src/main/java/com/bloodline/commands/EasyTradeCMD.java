package com.bloodline.commands;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Box;
import net.minecraft.village.TradeOffer;

public class EasyTradeCMD {
    public static void register() {

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {

            dispatcher.register(CommandManager.literal("easy_trade")
                .executes(context -> {
                    var player = context.getSource().getPlayer();
                    ServerWorld world = context.getSource().getWorld();

                    Box area = player.getBoundingBox().expand(5);

                    for (VillagerEntity villager : world.getEntitiesByClass(
                            VillagerEntity.class,
                            area,
                            v -> true)) {
                        for (TradeOffer offer : villager.getOffers()) {
                            offer.resetUses();
                        }
                    }

                    player.addStatusEffect(new StatusEffectInstance(
                            StatusEffects.HERO_OF_THE_VILLAGE,
                            1200, //20 * 60 (tps * seconds_per_minute)
                            255,
                            false,
                            false
                    ));
                    return 1;
                })
            );
        });
    }
}
