package com.bloodline.commands;

import com.bloodline.helpers.HeartHelper;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;

import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class CraftHeartCMD {

    public static void register() {

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {

            dispatcher.register(CommandManager.literal("craft_heart")
                    .executes(context -> {

                        ServerPlayerEntity player = context.getSource().getPlayer();

                        int keys = 0;
                        int totems = 0;
                        int apples = 0;

                        // CHECK INVENTORY
                        for (int i = 0; i < player.getInventory().size(); i++) {

                            ItemStack stack = player.getInventory().getStack(i);

                            if (stack.isOf(Items.OMINOUS_TRIAL_KEY)) {
                                keys += stack.getCount();
                            }

                            if (stack.isOf(Items.TOTEM_OF_UNDYING)) {
                                totems += stack.getCount();
                            }

                            if (stack.isOf(Items.GOLDEN_APPLE)) {
                                apples += stack.getCount();
                            }
                        }

                        // REQUIREMENTS
                        if (keys < 1 || totems < 1 || apples < 32) {

                            player.sendMessage(Text.literal("You are missing ingredients."), false);
                            player.sendMessage(Text.literal("Need: 32 golden apples, 1 ominous key, 1 totem"), false);

                            return 0;
                        }

                        // REMOVE ITEMS SAFELY
                        removeItems(player, Items.OMINOUS_TRIAL_KEY, 1);
                        removeItems(player, Items.TOTEM_OF_UNDYING, 1);
                        removeItems(player, Items.GOLDEN_APPLE, 32);

                        // CREATE HEART
                        ItemStack heart = HeartHelper.makeHeart();

                        if (!player.getInventory().insertStack(heart)) {
                            player.dropItem(heart, false);
                        }

                        return 1;
                    })
            );
        });
    }

    private static void removeItems(ServerPlayerEntity player, net.minecraft.item.Item item, int amount) {

        for (int i = 0; i < player.getInventory().size(); i++) {

            ItemStack stack = player.getInventory().getStack(i);

            if (stack.isOf(item)) {

                int take = Math.min(amount, stack.getCount());
                stack.decrement(take);
                amount -= take;

                if (amount <= 0) break;
            }
        }
    }
}