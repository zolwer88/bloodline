package com.bloodline.commands;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class CraftHayCMD {

    public static void register() {

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {

            dispatcher.register(CommandManager.literal("craft_hay")
                    .executes(context -> {

                        ServerPlayerEntity player = context.getSource().getPlayer();

                        int emeralds = 0;

                        // CHECK INVENTORY
                        for (int i = 0; i < player.getInventory().size(); i++) {

                            ItemStack stack = player.getInventory().getStack(i);

                            if (stack.isOf(Items.EMERALD_BLOCK)) {
                                emeralds += stack.getCount();
                            }
                        }

                        // REQUIREMENTS
                        if (emeralds < 1) {

                            player.sendMessage(Text.literal("You are missing ingredients."), false);
                            player.sendMessage(Text.literal("Need: 1 emerald block"), false);

                            return 0;
                        }

                        // REMOVE ITEMS SAFELY
                        removeItems(player, Items.EMERALD_BLOCK, 1);

                        // CREATE HEART
                        ItemStack hay = new ItemStack(Items.HAY_BLOCK);

                        if (!player.getInventory().insertStack(hay)) {
                            player.dropItem(hay, false);
                        }

                        return 1;
                    })
            );
        });
    }

    private static void removeItems(ServerPlayerEntity player, Item item, int amount) {

        for (int i = 0; i < player.getInventory().size(); i++) {

            ItemStack stack = player.getInventory().getStack(i);

            if (stack.isOf(item)) {

                int take = Math.min(amount, stack.getCount());
                stack.decrement(take);
                amount -= take;

                if (amount <= 0) break;
            }
        }
    }
}