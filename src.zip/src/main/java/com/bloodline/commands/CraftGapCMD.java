package com.bloodline.commands;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;

import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class CraftGapCMD {

    public static void register() {

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {

            dispatcher.register(CommandManager.literal("craft_gaps")
                    .executes(context -> {

                        ServerPlayerEntity player = context.getSource().getPlayer();

                        int gold = 0;
                        int apples = 0;

                        // CHECK INVENTORY
                        for (int i = 0; i < player.getInventory().size(); i++) {

                            ItemStack stack = player.getInventory().getStack(i);

                            if (stack.isOf(Items.GOLD_INGOT)) {
                                gold += stack.getCount();
                            }

                            if (stack.isOf(Items.APPLE)) {
                                apples += stack.getCount();
                            }
                        }

                        // REQUIREMENTS
                        if (gold < 8 || apples < 4) {

                            player.sendMessage(Text.literal("You are missing ingredients."), false);
                            player.sendMessage(Text.literal("Need: 4 apples, 8 gold"), false);

                            return 0;
                        }

                        // REMOVE ITEMS SAFELY
                        removeItems(player, Items.GOLD_INGOT, 8);
                        removeItems(player, Items.APPLE, 4);

                        // CREATE HEART
                        ItemStack gaps = new ItemStack(Items.GOLDEN_APPLE, 4);

                        if (!player.getInventory().insertStack(gaps)) {
                            player.dropItem(gaps, false);
                        }

                        return 1;
                    })
            );
        });
    }

    private static void removeItems(ServerPlayerEntity player, net.minecraft.item.Item item, int amount) {

        for (int i = 0; i < player.getInventory().size(); i++) {

            ItemStack stack = player.getInventory().getStack(i);

            if (stack.isOf(item)) {

                int take = Math.min(amount, stack.getCount());
                stack.decrement(take);
                amount -= take;

                if (amount <= 0) break;
            }
        }
    }
}