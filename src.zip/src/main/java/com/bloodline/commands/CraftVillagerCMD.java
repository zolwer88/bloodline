package com.bloodline.commands;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class CraftVillagerCMD {

    public static void register() {

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {

            dispatcher.register(CommandManager.literal("craft_villager")
                    .executes(context -> {

                        ServerPlayerEntity player = context.getSource().getPlayer();

                        int hay = 0;
                        int emeralds = 0;
                        boolean hasBed = false;
                        ItemStack bed = null;

                        // CHECK INVENTORY
                        for (int i = 0; i < player.getInventory().size(); i++) {

                            ItemStack stack = player.getInventory().getStack(i);

                            if (stack.isOf(Items.HAY_BLOCK)) {
                                hay += stack.getCount();
                            }

                            if (stack.isOf(Items.EMERALD_BLOCK)) {
                                emeralds += stack.getCount();
                            }

                            if (stack.isIn(ItemTags.BEDS)) {
                                hasBed = true;
                                bed = stack;
                            }
                        }

                        // REQUIREMENTS
                        if (hay < 2 || emeralds < 2 || !hasBed) {

                            player.sendMessage(Text.literal("You are missing ingredients."), false);
                            player.sendMessage(Text.literal("Need: 1 bed, 2 emerald blocks, 2 hay blocks"), false);

                            return 0;
                        }

                        // REMOVE ITEMS SAFELY
                        removeItems(player, Items.HAY_BLOCK, 2);
                        removeItems(player, Items.EMERALD_BLOCK, 2);
                        removeItems(player, bed.getItem(), 1);

                        // CREATE HEART
                        ItemStack egg = new ItemStack(Items.VILLAGER_SPAWN_EGG);

                        if (!player.getInventory().insertStack(egg)) {
                            player.dropItem(egg, false);
                        }

                        return 1;
                    })
            );
        });
    }

    private static void removeItems(ServerPlayerEntity player, Item item, int amount) {

        for (int i = 0; i < player.getInventory().size(); i++) {

            ItemStack stack = player.getInventory().getStack(i);

            if (stack.isOf(item)) {

                int take = Math.min(amount, stack.getCount());
                stack.decrement(take);
                amount -= take;

                if (amount <= 0) break;
            }
        }
    }
}