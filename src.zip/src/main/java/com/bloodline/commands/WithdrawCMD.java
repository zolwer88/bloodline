package com.bloodline.commands;

import com.bloodline.component.ModComponents;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.command.CommandManager;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class WithdrawCMD {
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("withdraw")
                .then(CommandManager.argument("Count", IntegerArgumentType.integer())
                    .executes(context -> {
                        var count = IntegerArgumentType.getInteger(context, "Count");
                        var player = context.getSource().getPlayer();
                        var attribute = player.getAttributeInstance(EntityAttributes.MAX_HEALTH);

                        if (attribute.getBaseValue() - (count * 2) < 6) {
                            player.sendMessage(Text.literal("you can't have less than 3 hearts"));
                            return 0;
                        }

                        ItemStack heart = new ItemStack(Items.RED_DYE);
                        heart.set(ModComponents.IS_HEART, true);
                        heart.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
                        heart.set(DataComponentTypes.CUSTOM_NAME, Text.literal("Heart").formatted(Formatting.DARK_RED));
                        heart.setCount(count);

                        boolean added = player.getInventory().insertStack(heart);
                        if (!added) {
                            player.dropItem(heart, false);
                        }

                        attribute.setBaseValue(attribute.getBaseValue() - (count * 2));

                        return 1;
                    })
                )
            );
        });
    }
}
