package com.bloodline.commands;

import com.bloodline.component.ModComponents;
import com.bloodline.helpers.HeartHelper;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class CraftCartCMD {

    public static void register() {

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {

            dispatcher.register(CommandManager.literal("craft_carts")
                    .executes(context -> {

                        ServerPlayerEntity player = context.getSource().getPlayer();

                        int hearts = 0;
                        int tnt = 0;
                        int carts = 0;

                        // Count ingredients
                        for (int i = 0; i < player.getInventory().size(); i++) {

                            ItemStack stack = player.getInventory().getStack(i);

                            if (Boolean.TRUE.equals(stack.get(ModComponents.IS_HEART))) {
                                hearts += stack.getCount();
                            }

                            if (stack.isOf(Items.TNT)) {
                                tnt += stack.getCount();
                            }

                            if (stack.isOf(Items.MINECART)) {
                                carts += stack.getCount();
                            }
                        }

                        if (hearts < 1 || tnt < 10 || carts < 3) {

                            player.sendMessage(Text.literal("You are missing ingredients."), false);
                            player.sendMessage(Text.literal("Need: 1 heart, 10 TNT, 3 minecarts"), false);

                            return 0;
                        }

                        // Remove TNT and minecarts
                        removeItems(player, Items.TNT, 10);
                        removeItems(player, Items.MINECART, 3);

                        // Remove one heart
                        for (int i = 0; i < player.getInventory().size(); i++) {

                            ItemStack stack = player.getInventory().getStack(i);

                            if (Boolean.TRUE.equals(stack.get(ModComponents.IS_HEART))) {
                                stack.decrement(1);
                                break;
                            }
                        }

                        // Give 8 legal TNT minecarts
                        for (int i = 0; i < 8; i++) {

                            ItemStack tntCart = new ItemStack(Items.TNT_MINECART);
                            tntCart.set(ModComponents.IS_LEGAL_CART, true);
                            tntCart.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
                            tntCart.set(
                                    DataComponentTypes.CUSTOM_NAME,
                                    Text.literal("Legal Cart").formatted(Formatting.RED)
                            );

                            if (!player.getInventory().insertStack(tntCart)) {
                                player.dropItem(tntCart, false);
                            }
                        }

                        return 1;
                    })
            );
        });
    }

    private static void removeItems(ServerPlayerEntity player, Item item, int amount) {

        for (int i = 0; i < player.getInventory().size(); i++) {

            ItemStack stack = player.getInventory().getStack(i);

            if (stack.isOf(item)) {

                int take = Math.min(amount, stack.getCount());
                stack.decrement(take);
                amount -= take;

                if (amount <= 0) {
                    break;
                }
            }
        }
    }
}